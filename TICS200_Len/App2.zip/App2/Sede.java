package App2;

public class Sede {
    String cod_sede;

    public Sede(String cod_sede) {
        this.cod_sede = cod_sede;
    }

    public String getCod_sede() {
        return cod_sede;
    }

    public void setCod_sede(String cod_sede) {
        this.cod_sede = cod_sede;
    }
}
