package App2;
public class Plan {
    private String cod_plan;

    public Plan(String cod_plan) {
        this.cod_plan = cod_plan;
    }
    
    public String getCod_plan() {
        return cod_plan;
    }
}