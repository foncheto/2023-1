package App2;

public class App2 {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.runMenu();
    }
}